package com.example.proyectin.controlador;

import android.app.Activity;
import android.content.Context;
import android.os.AsyncTask;
import android.widget.TextView;

import com.example.proyectin.R;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class HiloSW extends AsyncTask<String, Void, String>{



    public HiloSW(Context context) {
        this.context = context;
    }

    Context context;

    @Override
    protected String doInBackground(String... parametros) {

        String rutaUrl = parametros[0];
        String consulta = null;
        try{
            URL url = new URL(rutaUrl);
            HttpURLConnection conexion = (HttpURLConnection) url.openConnection();
            int respuesta = conexion.getResponseCode();
            if(respuesta == HttpURLConnection.HTTP_OK){
                InputStream in = new BufferedInputStream(conexion.getInputStream());
                BufferedReader lector = new BufferedReader(new InputStreamReader(in));
                consulta = lector.readLine();


            }else{
                consulta += "error: " + respuesta;

            }

        }catch (Exception ex){

        }

        return consulta;
    }
    @Override
    protected void onPostExecute(String s){
        TextView datos = ((Activity)context).findViewById(R.id.lblCargar);
        datos.setText(s);
    }


    }


