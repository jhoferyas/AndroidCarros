package com.example.proyectin.vista;

import android.net.Uri;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.example.proyectin.R;
import com.example.proyectin.vista.fragmentos.FrgColor1;
import com.example.proyectin.vista.fragmentos.FrgColor2;

public class ActivityFragmentos extends AppCompatActivity implements View.OnClickListener, FrgColor1.OnFragmentInteractionListener, FrgColor2.OnFragmentInteractionListener {
    Button btnColor1, btnColor2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fragmentos);

        btnColor1 = (Button) findViewById(R.id.btnColor1);
        btnColor2= (Button) findViewById((R.id.btnColor2));
        btnColor1.setOnClickListener(this);
        btnColor2.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
    switch (v.getId()){
        case R.id.btnColor1:
            FrgColor1 frg1 = new FrgColor1();
            FragmentTransaction transaction1 = getSupportFragmentManager().beginTransaction();

            transaction1.replace(R.id.contenedor, frg1);
            transaction1.commit();
            break;
        case R.id.btnColor2:
            FrgColor2 frg2 = new FrgColor2();
            FragmentTransaction transaction2 = getSupportFragmentManager().beginTransaction();

            transaction2.replace(R.id.contenedor, frg2);
            transaction2.commit();
            break;
    }
    }

    @Override
    public void onFragmentInteraction(Uri uri) {

    }
}
