package com.example.proyectin.controlador;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.proyectin.modelo.Producto;

import java.util.ArrayList;
import java.util.List;

public class HelperProducto extends SQLiteOpenHelper {

    //context es la actividad

    public HelperProducto(Context context) {
        super(context, "productoBD", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE producto (id_producto INTEGER PRIMARY KEY autoincrement, " +
                "codigo TEXT UNIQUE, nombre TEXT, descripcion TEXT, precio_unitario REAL, existencia INTEGER);");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {


    }

    public void insertar(Producto producto){
        ContentValues values = new ContentValues();
        values.put("codigo", producto.getCodigo());
        values.put("nombre", producto.getNombre());
        values.put("descripcion", producto.getDescripcion());
        values.put("precio_unitario", producto.getPrecio());
        values.put("existencia", producto.getExistencia());

        this.getWritableDatabase().insert("producto", null, values);


    }

    //cursor --> conjunto de tuplas
    public String leerTodos(){
        String consulta = "";
        Cursor cursor= this.getReadableDatabase().rawQuery("SELECT *FROM producto", null);
        if(cursor.moveToFirst());
           do {

               String nombre = cursor.getString(cursor.getColumnIndex("nombre"));
               String descripcion = cursor.getString(cursor.getColumnIndex("descripcion"));

               consulta += nombre + "-> " +descripcion;
               //consulta += nombre;


           }while(cursor.moveToNext());

        return consulta;
    }

    public void update(Producto producto){
        ContentValues values = new ContentValues();
        values.put("nombre",producto.getNombre());
        values.put("descripcion", producto.getDescripcion());
        values.put("precio_unitario", producto.getPrecio());
        values.put("existencia", producto.getExistencia());
        this.getWritableDatabase().update("producto",values,"codigo='" + producto.getCodigo() +"'",null);
    }


    public void eliminarPorCodigo(String codigo){
        this.getWritableDatabase().delete("producto","codigo='" + codigo + "'",null);
    }

    public String leerCodigo(String codigo){
        List<Producto> lista = new ArrayList<>();
        String consulta = "";
        Cursor cursor= this.getReadableDatabase().rawQuery("SELECT *FROM producto where codigo = '"+codigo+"'", null);
        if(cursor.moveToFirst());
        do {

            String nombre = cursor.getString(cursor.getColumnIndex("nombre"));


            consulta += nombre;


        }while(cursor.moveToNext());

        return consulta;
    }


    public List<Producto> getAllProductos(){
        List <Producto> lista = new ArrayList<Producto>();
        Cursor cursor = this.getReadableDatabase().rawQuery("SELECT * FROM producto", null);
        if(cursor.moveToFirst());
        do {
            Producto producto = new Producto();
            producto.setCodigo(cursor.getString(cursor.getColumnIndex("codigo")));
            producto.setNombre(cursor.getString(cursor.getColumnIndex("nombre")));
            producto.setDescripcion(cursor.getString(cursor.getColumnIndex("descripcion")));
            producto.setExistencia(cursor.getInt(cursor.getColumnIndex("existencia")));
            producto.setPrecio(cursor.getDouble(cursor.getColumnIndex("precio_unitario")));
            lista.add(producto);


        }while(cursor.moveToNext());
        cursor.close();

        return lista;
    }

    public List<Producto>getByCode(String codigo){
        List<Producto> lista = new ArrayList<Producto>();
        Cursor cursor= this.getReadableDatabase().rawQuery("SELECT *FROM producto where codigo = '"+codigo+"'", null);
        if(cursor.moveToFirst());
        do {

            Producto producto = new Producto();
            producto.setCodigo(cursor.getString(cursor.getColumnIndex("codigo")));
            producto.setNombre(cursor.getString(cursor.getColumnIndex("nombre")));
            producto.setDescripcion(cursor.getString(cursor.getColumnIndex("descripcion")));
            producto.setExistencia(cursor.getInt(cursor.getColumnIndex("existencia")));
            producto.setPrecio(cursor.getDouble(cursor.getColumnIndex("precio_unitario")));
            lista.add(producto);





        }while(cursor.moveToNext());
        cursor.close();

        return lista;
    }


}
