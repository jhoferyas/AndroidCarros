package com.example.proyectin.vista;

import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.proyectin.R;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.InputStreamReader;

public class ActividadLeerMI extends AppCompatActivity implements View.OnClickListener {
    Button boton;
    TextView datos;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_actividad_leer_mi);

        datos= findViewById(R.id.lbDatosMI);
        boton = findViewById((R.id.btnLeerArchivo));
        boton.setOnClickListener(this);
        setupActionBar();
    }
    private void setupActionBar(){
        ActionBar actionBar = getSupportActionBar();
        if(actionBar == null){
            actionBar.setDisplayHomeAsUpEnabled(true);
            actionBar.setTitle("Escribir Archivo");

        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
        case R.id.btnLeerArchivo:
          try{
                BufferedReader lector = new BufferedReader(new InputStreamReader(openFileInput("archivo.txt")));
                datos.setText(lector.readLine()
                );
                lector.close();
            } catch (Exception ex) {
                Log.e("Error Lectura", ex.getMessage());
            }

        }
    }
}
