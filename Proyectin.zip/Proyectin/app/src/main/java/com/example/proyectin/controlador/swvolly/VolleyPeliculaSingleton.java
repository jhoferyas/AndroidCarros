package com.example.proyectin.controlador.swvolly;

import android.content.Context;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.Volley;

public class VolleyPeliculaSingleton {

    private RequestQueue queue;
    private Context context;
    private static  VolleyPeliculaSingleton miInstacia;

    public VolleyPeliculaSingleton(Context contexto) {
        context = contexto;
        queue = getRequestQueue();

    }

    public RequestQueue getRequestQueue(){
        if(queue == null){
            queue = Volley.newRequestQueue(context.getApplicationContext());
        }
        return queue;
    }

    public static synchronized VolleyPeliculaSingleton getInstance(Context contexto){
        if(miInstacia == null){
            miInstacia = new VolleyPeliculaSingleton(contexto);
        }
        return miInstacia;
    }


    public <T> void addToRequestque(Request request){
        queue.add(request);
    }

}
