package com.example.proyectin.vista;

import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.proyectin.R;
import com.example.proyectin.controlador.swvolly.ServicioWebVolley;
import com.example.proyectin.modelo.Alumno;
import com.example.proyectin.vista.adapter.AlumnoAdapter;

import java.util.ArrayList;
import java.util.List;

public class ActividadSWVolly extends AppCompatActivity implements View.OnClickListener {
    EditText cajaID, cajaNombre, cajaDireccion;
    Button botonGuardar, botonModificar, botonEliminar, botonBuscarTodos, botonBuscarId;
    ServicioWebVolley servicioWebVolley;

    RecyclerView recyclerViewAlumno;
    AlumnoAdapter adapter;
    private  List<Alumno> alumnos;





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_actividad_swvolly);
        tomarControl();
        setupActionBar();
        servicioWebVolley = new ServicioWebVolley(ActividadSWVolly.this);

        cargarLista(servicioWebVolley.obtenerTodos());


    }


    public void tomarControl(){
        cajaID = findViewById(R.id.txtIdAlumnoVolly);
        cajaNombre = findViewById(R.id.txtNombreAlumnoVolly);
        cajaDireccion = findViewById(R.id.txtDireccionAlumnoVolly);

        botonGuardar = findViewById(R.id.btnInsertarAlumnoVolly);
        botonModificar = findViewById(R.id.btnActualizarAlumnoVolly);
        botonEliminar = findViewById(R.id.btnEliminarAlumnoVolly);
        botonBuscarId = findViewById(R.id.btnBuscarIDAlumnoVolly);
        botonBuscarTodos = findViewById(R.id.btnBuscarTodosAlumnosVolly);

        botonGuardar.setOnClickListener(this);
        botonModificar.setOnClickListener(this);
        botonEliminar.setOnClickListener(this);
        botonBuscarId.setOnClickListener(this);
        botonBuscarTodos.setOnClickListener(this);

    }


    private void setupActionBar(){
        ActionBar actionBar = getSupportActionBar();
        if(actionBar == null){
            actionBar.setDisplayHomeAsUpEnabled(true);
            //actionBar.setTitle("Escribir Archivo");

        }
    }

    private void cargarLista(List<Alumno> lista) {
       // List<Alumno> alumnos = new ArrayList<Alumno>();
        alumnos = new ArrayList<Alumno>();
        alumnos = lista;
        /*alumnos.add(new Alumno("001", "Jhon", "Loja"));
        alumnos.add(new Alumno("002", "Faver", "Colombia"));
        alumnos.add(new Alumno("003", "Andres", "Quito"));*/
        adapter = new AlumnoAdapter(alumnos);
        adapter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Alumno a = adapter.obtenerAlumno(recyclerViewAlumno.getChildAdapterPosition(v));
                cajaID.setText(a.getId());
                cajaNombre.setText(a.getNombre());
                cajaDireccion.setText(a.getDireccion());
            }
        });
        recyclerViewAlumno = findViewById(R.id.recyclerAlumnoVolly);
        recyclerViewAlumno.setLayoutManager(new LinearLayoutManager(this));
        recyclerViewAlumno .setAdapter(adapter);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btnInsertarAlumnoVolly:
                Alumno alumno = new Alumno();
                alumno.setNombre(cajaNombre.getText().toString());
                alumno.setDireccion(cajaDireccion.getText().toString());
                boolean estado = servicioWebVolley.insertar(alumno);
                if (estado)
                    Toast.makeText(this, "No se ha podido registrar el alumno", Toast.LENGTH_LONG).show();
                else
                    Toast.makeText(this, " Alumno registrado", Toast.LENGTH_LONG).show();


                break;

            case R.id.btnActualizarAlumnoVolly:
                Alumno alumno2 = new Alumno();
                alumno2.setId(cajaID.getText().toString());
                alumno2.setNombre(cajaNombre.getText().toString());
                alumno2.setDireccion(cajaDireccion.getText().toString());
                boolean estado2 = servicioWebVolley.modificar(alumno2);
                if (estado2)
                    Toast.makeText(this, "No se ha podido actualizar el alumno ", Toast.LENGTH_LONG).show();
                else
                    Toast.makeText(this, "Alumno actualizado", Toast.LENGTH_LONG).show();


                break;
            case R.id.btnEliminarAlumnoVolly:
                Alumno alumno3 = new Alumno();
                alumno3.setId(cajaID.getText().toString());
                boolean estado3 = servicioWebVolley.eliminar(alumno3);
                if (estado3)
                    Toast.makeText(this, "No se ha podido eliminar el alumno ", Toast.LENGTH_LONG).show();
                else
                    Toast.makeText(this, "Alumno eliminado", Toast.LENGTH_LONG).show();


                break;

            case R.id.btnBuscarTodosAlumnosVolly:
               // servicioWebVolley.obtenerTodos();
                cargarLista(servicioWebVolley.obtenerTodos());
               // Log.e("LIsta",servicioWebVolley.obtenerTodos().toString());

                break;

            case R.id.btnBuscarIDAlumnoVolly:
                // servicioWebVolley.obtenerTodos();
                cargarLista(servicioWebVolley.obtenerPorId("?idalumno=" + cajaID.getText().toString()));
               // Log.e("ID", servicioWebVolley.obtenerPorId("?idalumno=" + cajaID.getText().toString())+"");

                break;

        }


    }
}
