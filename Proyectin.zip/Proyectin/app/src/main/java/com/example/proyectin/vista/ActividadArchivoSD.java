package com.example.proyectin.vista;

import android.os.Environment;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.proyectin.R;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

public class ActividadArchivoSD extends AppCompatActivity implements View.OnClickListener {
    EditText cajaNombre, cajaExistencia, cajaPrecio, cajaCodigo;
    Button botonEscribir, botonLeer;
    TextView datos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_actividad_archivo_sd);
        cajaNombre = findViewById(R.id.txtNombreProductoSD);
        cajaCodigo = findViewById(R.id.txtCodigoProductoSD);
        cajaPrecio = findViewById(R.id.txtPrecioProductoSD);
        cajaExistencia = findViewById(R.id.txtExistenciaSD);
        datos = findViewById(R.id.lblDatosSD);
        botonEscribir = findViewById(R.id.btnEscribirSD);
        botonLeer = findViewById(R.id.btnLeerSD);
        botonEscribir.setOnClickListener(this);
        botonLeer.setOnClickListener(this);
        setupActionBar();



    }
    private void setupActionBar(){
        ActionBar actionBar = getSupportActionBar();
        if(actionBar == null){
            actionBar.setDisplayHomeAsUpEnabled(true);
            actionBar.setTitle("Escribir Archivo");

        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btnEscribirSD:
                try {
                    File ruta = Environment.getExternalStorageDirectory();
                    File f = new File(ruta.getAbsolutePath(), "archivo.txt");
                    OutputStreamWriter escritor = new OutputStreamWriter(new FileOutputStream(f));
                    escritor.write(cajaNombre.getText().toString() + ","
                            + cajaCodigo.getText().toString() + ","
                            + cajaExistencia.getText().toString() + ","
                            + cajaPrecio.getText().toString() + ";");
                    escritor.close();

                }catch (Exception ex){
                    Log.e("Error Escritura SD",ex.getMessage());
                }
                break;

            case R.id.btnLeerSD:
                try {
                    File ruta = Environment.getExternalStorageDirectory();
                    File f = new File(ruta.getAbsolutePath(), "archivo.txt");
                    BufferedReader lector = new BufferedReader( new InputStreamReader( new FileInputStream(f)));

                    String texto = lector.readLine();
                    datos.setText(texto);
                    lector.close();
                }catch (Exception ex){
                    Log.e("Error Escritura SD",ex.getMessage());
                }
                break;
        }
    }
}


