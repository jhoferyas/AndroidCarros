package com.example.proyectin.vista.adapter;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.proyectin.R;
import com.example.proyectin.modelo.Producto;

import java.util.List;

public class ProductoAdapter extends RecyclerView.Adapter <ProductoAdapter.ViewHolder> implements View.OnClickListener{
    List<Producto> lista;

    //evento
    private View.OnClickListener listener;

    public ProductoAdapter(List<Producto> lista) {

        this.lista = lista;
    }



    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.layout_item_producto, null);
        view.setOnClickListener(this);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder viewHolder, int posicion) {
        //se fija los datos en cada fila atravez del holderView
        viewHolder.nombre.setText(lista.get(posicion).getNombre());
        viewHolder.codigo.setText(lista.get(posicion).getCodigo());



    }

    @Override
    public int getItemCount() {

        return lista.size();
    }
//esto lo hice yo
    public void setOnClickListener(View.OnClickListener listener){

        this.listener = listener;
    }



    @Override
    public void onClick(View v) {
            if(listener != null){
                listener.onClick(v);
            }


    }


    public static class ViewHolder extends RecyclerView.ViewHolder{
        TextView nombre;
        TextView codigo;



        public ViewHolder(View itemView) {
            super(itemView);
            codigo = itemView.findViewById(R.id.lblCodigoCard);
            nombre = itemView.findViewById(R.id.lblNombreCard);


        }
    }


}
