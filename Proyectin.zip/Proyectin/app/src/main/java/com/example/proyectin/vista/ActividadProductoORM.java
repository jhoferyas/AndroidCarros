package com.example.proyectin.vista;

import android.app.Dialog;
import android.content.Intent;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.proyectin.R;
import com.example.proyectin.vista.adapter.ProductoAdapter;
import com.example.proyectin.modelo.config.AplicacionORM;
import com.example.proyectin.modelo.Producto;

import java.util.ArrayList;
import java.util.List;

public class ActividadProductoORM extends AppCompatActivity implements View.OnClickListener {
    Button botonAgregar;
    RecyclerView recyclerView;
    List<Producto> listaProducto;
    ProductoAdapter adapter;
    AplicacionORM app;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_actividad_producto_orm);
        botonAgregar = findViewById(R.id.btnAgregarORM);
        recyclerView = findViewById(R.id.recyclerProductoORM);
        botonAgregar.setOnClickListener(this);
        listaProducto = new ArrayList<Producto>();
        listaProducto = Producto.getAll();
        cargarLista();
        setupActionBar();

    }
    private void cargarLista(){
        listaProducto = new ArrayList<Producto>();
        listaProducto = Producto.getAll();
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new ProductoAdapter(listaProducto);
        adapter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final Producto producto = listaProducto.get(recyclerView.getChildAdapterPosition(v));
                final Dialog dialogInformation = new Dialog(ActividadProductoORM.this);
                dialogInformation.requestWindowFeature(Window.FEATURE_LEFT_ICON);
                dialogInformation.setContentView(R.layout.dlg_modificar_orm);
                dialogInformation.setTitle("Informacion");

                final TextView codigo = dialogInformation.findViewById(R.id.lblCodigoDlg);
                final EditText nombre = dialogInformation.findViewById(R.id.txtNombreDlg);
                final EditText descripcion = dialogInformation.findViewById(R.id.txtDescripcionDlg);
                final EditText precio = dialogInformation.findViewById(R.id.txtPrecioDlg);
                final EditText existencia = dialogInformation.findViewById(R.id.txtExistenciaDlg);
                Button botonModificar = dialogInformation.findViewById(R.id.btnModificarORM);

                botonModificar.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        producto.setNombre(nombre.getText().toString());
                        producto.setDescripcion(descripcion.getText().toString());
                        producto.setPrecio(Double.parseDouble(precio.getText().toString()));
                        producto.setExistencia(Integer.parseInt(existencia.getText().toString()));
                        producto.save();
                        cargarLista();
                        dialogInformation.hide();


                    }
                });

                dialogInformation.show();



                codigo.setText(Producto.getAll().get(recyclerView.getChildAdapterPosition(v)).getCodigo());
                nombre.setText(Producto.getAll().get(recyclerView.getChildAdapterPosition(v)).getNombre());
                descripcion.setText(Producto.getAll().get(recyclerView.getChildAdapterPosition(v)).getDescripcion());
                precio.setText(Producto.getAll().get(recyclerView.getChildAdapterPosition(v)).getPrecio()+"");
                existencia.setText(Producto.getAll().get(recyclerView.getChildAdapterPosition(v)).getExistencia()+"");

                Toast.makeText(getApplicationContext(), "Selecciono: "+
                               Producto.getAll().get(recyclerView.getChildAdapterPosition(v)).getCodigo()+" "+
                        Producto.getAll().get(recyclerView.getChildAdapterPosition(v)).getNombre(),
                        Toast.LENGTH_SHORT).show();
            }
        });
        recyclerView.setAdapter(adapter);
    }
    private void setupActionBar(){
        ActionBar actionBar = getSupportActionBar();
        if(actionBar == null){
            actionBar.setDisplayHomeAsUpEnabled(true);
            actionBar.setTitle("Escribir Archivo");

        }
    }



    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btnAgregarORM:
                Intent intent = new Intent(ActividadProductoORM.this, ActividadAddProductoORM.class);
                startActivity(intent);
                cargarLista();
                break;

        }

    }
}
