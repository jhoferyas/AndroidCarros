package com.example.proyectin.modelo.config;

import com.activeandroid.ActiveAndroid;
import com.activeandroid.app.Application;

public class AplicacionORM extends Application {


    @Override
    public void onCreate() {
        super.onCreate();
        ActiveAndroid.initialize(this);

    }


    /*public void update(Producto producto){
        ContentValues values = new ContentValues();
        values.put("nombre", producto.getNombre());
        values.put("desccripcion", producto.getDescripcion());
        values.put("existencia", producto.getExistencia());
        values.put("precio", producto.getPrecio());


    }*/

}
