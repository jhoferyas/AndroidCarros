package com.example.proyectin.vista;


import android.os.AsyncTask;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;


import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.proyectin.R;
import com.example.proyectin.vista.adapter.AlumnoAdapter;
import com.example.proyectin.modelo.Alumno;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.List;

public class ActividadSWHAlumno extends AppCompatActivity implements View.OnClickListener {
    EditText cajaID, cajaNombre, cajaDireccion;
    Button botonGuardar, botonModificar, botonEliminar, botonBuscarTodos, botonBuscarId;
    RecyclerView recyclerViewAlumno;
    AlumnoAdapter adapter;
    ServicioWeb sw;
    private List<Alumno> listaAlumno;



    String HOST = "http://reneguaman.000webhostapp.com";
    String GET = HOST.concat("/obtener_alumnos.php");
    String GET_BY_ID = HOST.concat("/obtener_alumno_por_id.php");
    String INSERT = HOST.concat("/insertar_alumno.php");
    String UPDATE = HOST.concat("/actualizar_alumno.php");
    String DELETE = HOST.concat("/borrar_alumno.php");



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_actividad_swhalumno);
        tomarControl();
        //cargarLista();
        setupActionBar();






    }
    public void tomarControl(){
        cajaID = findViewById(R.id.txtIdAlumno);
        cajaNombre = findViewById(R.id.txtNombreAlumno);
        cajaDireccion = findViewById(R.id.txtDireccionAlumno);

        botonGuardar = findViewById(R.id.btnInsertarAlumno);
        botonModificar = findViewById(R.id.btnActualizarAlumno);
        botonEliminar = findViewById(R.id.btnEliminarAlumno);
        botonBuscarId = findViewById(R.id.btnBuscarIDAlumno);
        botonBuscarTodos = findViewById(R.id.btnBuscarTodosAlumnos);

        botonGuardar.setOnClickListener(this);
        botonModificar.setOnClickListener(this);
        botonEliminar.setOnClickListener(this);
        botonBuscarId.setOnClickListener(this);
        botonBuscarTodos.setOnClickListener(this);

    }
    private void cargarLista(List<Alumno> lista) {
        List<Alumno> alumnos = new ArrayList<Alumno>();
        alumnos = lista;
        /*alumnos.add(new Alumno("001", "Jhon", "Loja"));
        alumnos.add(new Alumno("002", "Faver", "Colombia"));
        alumnos.add(new Alumno("003", "Andres", "Quito"));*/
        adapter = new AlumnoAdapter(alumnos);
        adapter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Alumno a = adapter.obtenerAlumno(recyclerViewAlumno.getChildAdapterPosition(v));
                cajaID.setText(a.getId());
                cajaNombre.setText(a.getNombre());
                cajaDireccion.setText(a.getDireccion());
            }
        });
        recyclerViewAlumno = findViewById(R.id.recyclerAlumnoSWH);
        recyclerViewAlumno.setLayoutManager(new LinearLayoutManager(this));
        recyclerViewAlumno .setAdapter(adapter);
    }


    private void setupActionBar(){
        ActionBar actionBar = getSupportActionBar();
        if(actionBar == null){
            actionBar.setDisplayHomeAsUpEnabled(true);
            actionBar.setTitle("Escribir Archivo");

        }
    }



    public void limpiarCajas(){
        cajaID.setText("");
        cajaNombre.setText("");
        cajaDireccion.setText("");
    }



    @Override
    public void onClick(View v) {
        sw = new ServicioWeb();
        switch (v.getId()){
            case R.id.btnBuscarTodosAlumnos:

                sw.execute("http://reneguaman.000webhostapp.com/obtener_alumnos.php", "1"); //ejecuta al hilo doInBackground
                break;

            case R.id.btnBuscarIDAlumno:
                sw.execute(GET_BY_ID + "?idalumno=" + cajaID.getText().toString(),"2");
                break;
            case R.id.btnInsertarAlumno:
                sw.execute(INSERT, "3", cajaNombre.getText().toString(), cajaDireccion.getText().toString());
                break;

            case R.id.btnActualizarAlumno:
                sw.execute(UPDATE, "4",cajaID.getText().toString(), cajaNombre.getText().toString(), cajaDireccion.getText().toString());
                break;
            case R.id.btnEliminarAlumno:
                sw.execute(DELETE, "5",cajaID.getText().toString());
                break;

        }

    }

    private void descomponerConsulta(int operacion, String cadena){
        if(operacion == 1) {
            try {
                JSONObject json = new JSONObject(cadena);
                String estado = json.getString("estado");
                List<Alumno> lista = new ArrayList<Alumno>();

                if (estado.equals("1")) {
                    JSONArray alumnosJSON = json.getJSONArray("alumnos");
                    for (int i = 0; i < alumnosJSON.length(); i++) {
                        Alumno alumno = new Alumno();
                        alumno.setId(alumnosJSON.getJSONObject(i).getString("idalumno"));
                        alumno.setNombre(alumnosJSON.getJSONObject(i).getString("nombre"));
                        alumno.setDireccion(alumnosJSON.getJSONObject(i).getString("direccion"));
                        lista.add(alumno);


                    }
                    cargarLista(lista);
                } else {
                    //cuando no hay estudiantes
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }else if (operacion == 2){
            JSONObject json = null;
            try {
                json = new JSONObject(cadena);
                String estado = json.getString("estado");
                List<Alumno> lista = new ArrayList<Alumno>();
                if(estado.equals("1")){
                    Alumno alumno = new Alumno();
                    alumno.setId(json.getJSONObject("alumno").getString("idAlumno"));
                    alumno.setNombre(json.getJSONObject("alumno").getString("nombre"));
                    alumno.setDireccion(json.getJSONObject("alumno").getString("direccion"));
                    lista.add(alumno);
                    cargarLista(lista);
                }else{
                    Toast.makeText(getApplicationContext(), "No existe ese estudiante", Toast.LENGTH_LONG).show();

                }
            } catch (JSONException e) {
                e.printStackTrace();
            }


        }else if(operacion == 3){
            JSONObject json = null;
            try{
                json = new JSONObject(cadena);
                String estado = json.getString("estado");
                if(estado.equals("1")){
                    Toast.makeText(getApplicationContext(), "Alumno insertado correctamente", Toast.LENGTH_LONG).show();
                    sw = new ServicioWeb();
                    sw.execute("GET", "1");

                }else{
                    Toast.makeText(getApplicationContext(), "No se registro el alumno", Toast.LENGTH_LONG).show();
                }

            }catch (JSONException e) {
                e.printStackTrace();
            }
        }else if(operacion == 4){
            JSONObject json = null;
            try{
                json = new JSONObject(cadena);
                String estado = json.getString("estado");
                if(estado.equals("1")){
                    Toast.makeText(getApplicationContext(), "Alumno actualizado correctamente", Toast.LENGTH_LONG).show();
                    sw = new ServicioWeb();
                    sw.execute("GET", "1");

                }else{
                    Toast.makeText(getApplicationContext(), "No se actualizo el alumno", Toast.LENGTH_LONG).show();
                }

            }catch (JSONException e) {
                e.printStackTrace();
            }
        }else if(operacion == 5){
            JSONObject json = null;
            try{
                json = new JSONObject(cadena);
                String estado = json.getString("estado");
                if(estado.equals("1")){
                    Toast.makeText(getApplicationContext(), "Alumno eliminado correctamente", Toast.LENGTH_LONG).show();
                    sw = new ServicioWeb();
                    sw.execute("GET", "1");

                }else{
                    Toast.makeText(getApplicationContext(), "No se elimino el alumno", Toast.LENGTH_LONG).show();
                }

            }catch (JSONException e) {
                e.printStackTrace();
            }
        }

    }


    class ServicioWeb extends AsyncTask<String, Void, String> {

        @Override
        protected String doInBackground(String... parametros) {
            String consulta = "";
            URL url =  null;
            String ruta = parametros[0];
            if (parametros[1].equals("1") || parametros[1].equals("2" )) {
                try {
                    url = new URL(ruta);
                    HttpURLConnection conexion = (HttpURLConnection) url.openConnection();
                    int codigoRespuesta = conexion.getResponseCode();
                    if(codigoRespuesta == HttpURLConnection.HTTP_OK){
                        InputStream in = new BufferedInputStream(conexion.getInputStream());
                        BufferedReader lector = new BufferedReader(new InputStreamReader(in));
                        consulta += lector.readLine();

                    }else{
                        consulta += "No hay conexion";

                    }

                } catch (MalformedURLException e) {
                    Log.e("error",e.getMessage());
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                    Log.e("erro2r",e.getMessage());
                }
                consulta = parametros[1] + "-" + consulta;
                //insertar
            } else if (parametros[1].equals("3")) {
                try {
                    url = new URL(ruta);
                   URLConnection conexion =  (HttpURLConnection)url.openConnection();
                   //configuracion para enviar por post un json
                    conexion.setDoInput(true);
                    conexion.setDoOutput(true);
                    conexion.setUseCaches(false);
                    conexion.setRequestProperty("Content-Type", "application/json");
                    conexion.setRequestProperty("Accept", "application/json");
                    conexion.connect();
                   //construir json
                    JSONObject json = new JSONObject();
                    json.put("nombre", parametros[2]);
                    json.put("direccion", parametros[3]);
                    //crear un buffer para enviar el json al metodo del sw
                    OutputStream os = conexion.getOutputStream();
                    BufferedWriter escritor = new BufferedWriter(new OutputStreamWriter(os, "UTF-8"));
                    escritor.write(json.toString());
                    escritor.flush();
                    escritor.close();
                    //recibir la respuesta del sw
                    int codigoRespuesta = ((HttpURLConnection)conexion).getResponseCode();
                    if(codigoRespuesta == HttpURLConnection.HTTP_OK){
                        BufferedReader lector = new BufferedReader((new InputStreamReader(conexion.getInputStream())));
                        consulta += lector.readLine();

                    }


                } catch (MalformedURLException e) {
                    Log.e("error",e.getMessage());
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                consulta = parametros[1] + "-" + consulta;

                //modificar
            }else if (parametros[1].equals("4")) {
                try {
                    url = new URL(ruta);
                    URLConnection conexion =  (HttpURLConnection)url.openConnection();
                    //configuracion para enviar por post un json
                    conexion.setDoInput(true);
                    conexion.setDoOutput(true);
                    conexion.setUseCaches(false);
                    conexion.setRequestProperty("Content-Type", "application/json");
                    conexion.setRequestProperty("Accept", "application/json");
                    conexion.connect();
                    //construir json
                    JSONObject json = new JSONObject();
                    json.put("idalumno", parametros[2]);
                    json.put("nombre", parametros[3]);
                    json.put("direccion", parametros[4]);
                    //crear un buffer para enviar el json al metodo del sw
                    OutputStream os = conexion.getOutputStream();
                    BufferedWriter escritor = new BufferedWriter(new OutputStreamWriter(os, "UTF-8"));
                    escritor.write(json.toString());
                    escritor.flush();
                    escritor.close();
                    //recibir la respuesta del sw
                    int codigoRespuesta = ((HttpURLConnection)conexion).getResponseCode();
                    if(codigoRespuesta == HttpURLConnection.HTTP_OK){
                        BufferedReader lector = new BufferedReader((new InputStreamReader(conexion.getInputStream())));
                        consulta += lector.readLine();

                    }





                } catch (MalformedURLException e) {
                    Log.e("error",e.getMessage());
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                consulta = parametros[1] + "-" + consulta;
                //Eliminar
            }else if (parametros[1].equals("5")) {
                try {
                    url = new URL(ruta);
                    URLConnection conexion =  (HttpURLConnection)url.openConnection();
                    //configuracion para enviar por post un json
                    conexion.setDoInput(true);
                    conexion.setDoOutput(true);
                    conexion.setUseCaches(false);
                    conexion.setRequestProperty("Content-Type", "application/json");
                    conexion.setRequestProperty("Accept", "application/json");
                    conexion.connect();
                    //construir json
                    JSONObject json = new JSONObject();
                    json.put("idalumno", parametros[2]);
                    //crear un buffer para enviar el json al metodo del sw
                    OutputStream os = conexion.getOutputStream();
                    BufferedWriter escritor = new BufferedWriter(new OutputStreamWriter(os, "UTF-8"));
                    escritor.write(json.toString());
                    escritor.flush();
                    escritor.close();
                    //recibir la respuesta del sw
                    int codigoRespuesta = ((HttpURLConnection)conexion).getResponseCode();
                    if(codigoRespuesta == HttpURLConnection.HTTP_OK){
                        BufferedReader lector = new BufferedReader((new InputStreamReader(conexion.getInputStream())));
                        consulta += lector.readLine();

                    }





                } catch (MalformedURLException e) {
                    Log.e("error",e.getMessage());
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                consulta = parametros[1] + "-" + consulta;
            }

            return consulta;
        }

        @Override
        protected void onPostExecute(String s) {
            Log.d("Datos", s);
            descomponerConsulta(Integer.parseInt(s.charAt(0)+""),s.substring(2,s.length()));



        }

    }


}
