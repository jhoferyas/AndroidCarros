package com.example.proyectin.vista.adapter;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.proyectin.R;
import com.example.proyectin.modelo.Pelicula;
import com.squareup.picasso.Picasso;

import java.util.List;

public class PeliculaAdapter extends RecyclerView.Adapter <PeliculaAdapter.PeliculaHolder> implements View.OnClickListener {

    List<Pelicula> lista;
    private View.OnClickListener listener;
    Context context;

    public PeliculaAdapter(List<Pelicula> lista, Context context) {
        this.lista = lista;
        this.context = context;
    }



    @NonNull
    @Override
    public PeliculaAdapter.PeliculaHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.layout_item_pelicula, null);
        view.setOnClickListener(this);
        return new PeliculaAdapter.PeliculaHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull PeliculaAdapter.PeliculaHolder peliculaHolder, int posicion) {
        Picasso.with(context).load(lista.get(posicion).getPoster()).into(peliculaHolder.imagen);
        peliculaHolder.idPelicula.setText(lista.get(posicion).getIdPelicula());
        peliculaHolder.titulo.setText(lista.get(posicion).getTitulo());




    }

    @Override
    public int getItemCount() {
        return lista.size();
    }

    public void setOnClickListener(View.OnClickListener listener){

        this.listener = listener;
    }

    @Override
    public void onClick(View v) {
        if(listener != null){
            listener.onClick(v);
        }

    }

    public static class PeliculaHolder extends RecyclerView.ViewHolder{
        TextView idPelicula;
        TextView titulo;
        ImageView imagen;


        public PeliculaHolder(@NonNull View itemView) {
            super(itemView);

            idPelicula = itemView.findViewById(R.id.lblIDPelicula);
            titulo = itemView.findViewById(R.id.lblTituloPelicula);
            imagen = itemView.findViewById(R.id.imgPelicula);
        }
    }

    public Pelicula obtenerPelicula(int pos){
        Pelicula pelicula = lista.get(pos);
        return pelicula;
    }

}
