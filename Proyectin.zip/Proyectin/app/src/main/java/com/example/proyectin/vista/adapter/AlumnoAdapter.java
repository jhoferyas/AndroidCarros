package com.example.proyectin.vista.adapter;



import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.proyectin.R;
import com.example.proyectin.modelo.Alumno;

import java.util.List;

public class AlumnoAdapter extends RecyclerView.Adapter <AlumnoAdapter.AlumnoHolder> implements View.OnClickListener{

    List<Alumno> lista;
    private View.OnClickListener listener;

    public AlumnoAdapter(List<Alumno> lista) {
        this.lista = lista;
    }


    @NonNull
    @Override
    public AlumnoAdapter.AlumnoHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.layout_item_alumno, null);
        view.setOnClickListener(this);
        return new AlumnoAdapter.AlumnoHolder(view);

    }

    @Override
    public void onBindViewHolder(@NonNull AlumnoAdapter.AlumnoHolder alumnoHolder, int posicion) {
        alumnoHolder.idAlumno.setText(lista.get(posicion).getId());
        alumnoHolder.nombre.setText(lista.get(posicion).getNombre());

    }

    @Override
    public int getItemCount() {

        return lista.size();
    }

    //esto lo hice yo
    public void setOnClickListener(View.OnClickListener listener){

        this.listener = listener;
    }

    @Override
    public void onClick(View v) {
        if(listener != null){
            listener.onClick(v);
        }


    }

    public static class AlumnoHolder extends RecyclerView.ViewHolder{
        TextView idAlumno;
        TextView nombre;


        public AlumnoHolder(@NonNull View itemView) {
            super(itemView);

            idAlumno = itemView.findViewById(R.id.lblIDAlumno);
            nombre = itemView.findViewById(R.id.lblNombreAlumno);
        }
    }

    public Alumno obtenerAlumno(int pos){
        Alumno alumno = lista.get(pos);
        return alumno;
    }

    public void addAlumno(Alumno a){
        lista.add(a);
    }

}
