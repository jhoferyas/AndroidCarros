package com.example.proyectin.controlador;

import android.content.Context;
import android.util.Log;

import com.example.proyectin.R;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;

public class LeerRaw {
    Context context;

    public LeerRaw(Context context) {
        this.context = context;
    }

    public String leerArchivoRaw(){
        String datos = null;
        try{

            InputStream input = context.getResources().openRawResource(R.raw.archivo_raw);
            BufferedReader lector = new BufferedReader(new InputStreamReader(input));
            datos = lector.readLine();
            input.close();
            lector.close();
        }catch (Exception ex){
            Log.e("Error Leer Raw ", ex.getMessage());
        }
        return datos;
    }
}
