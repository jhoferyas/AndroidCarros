package com.example.proyectin.modelo;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Base64;

public class Pelicula {
    private String idPelicula;
    private String titulo;
    private String año;
    private String tipo;
    private String poster;


    public Pelicula(String idPelicula, String titulo, String año, String tipo, String poster) {
        this.idPelicula = idPelicula;
        this.titulo = titulo;
        this.año = año;
        this.tipo = tipo;
        this.poster = poster;
    }

    public Pelicula() {
    }

    public String getIdPelicula() {
        return idPelicula;
    }

    public void setIdPelicula(String idPelicula) {
        this.idPelicula = idPelicula;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getAño() {
        return año;
    }

    public void setAño(String año) {
        this.año = año;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }


    public String  getPoster() {
        return poster;
    }

    public void setPoster(String  poster) {
        this.poster = poster;
    }

    @Override
    public String toString(){ return idPelicula+ ", "+titulo +", " + año + ", "+tipo + ", "+poster +";";
    }
}
