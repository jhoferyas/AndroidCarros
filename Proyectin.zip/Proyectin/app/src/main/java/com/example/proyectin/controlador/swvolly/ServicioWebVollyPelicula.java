package com.example.proyectin.controlador.swvolly;

import android.content.Context;
import android.util.Log;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.example.proyectin.modelo.Pelicula;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class ServicioWebVollyPelicula {
    //http://www.omdbapi.com/?apikey=6418afb3&s=avengers
    String host = "http://www.omdbapi.com/?";
    //String buscar_todos = "/?apikey=6418afb3&s=Avengers";
    //String buscar_titulo =  "/?apikey=6418afb3&t=";
    //String buscar_id = "/?apikey=6418afb3&i=";
    String api_key = "&apikey=6418afb3";



    Context context;
    final private List<Pelicula> listaPelicula;

    public ServicioWebVollyPelicula(Context context) {
        this.context = context;
        listaPelicula = new ArrayList<Pelicula>();
    }


    public List<Pelicula> obtenerTodos(String titulo, String filtro) {
        String url = host + filtro + titulo + api_key;
        Log.e("URL", url);
        listaPelicula.clear();



        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                //me devuelve un json
                try {
                    Log.d("DATOS", response.toString());
                    //String r = response.getString("Response");



                        JSONArray jsonPeliculas = response.getJSONArray("Search");
                        Toast.makeText(context, "Total peliculas: " + jsonPeliculas.length(), Toast.LENGTH_LONG).show();
                        for (int i = 0; i < jsonPeliculas.length(); i++) {
                            JSONObject jsonObject = jsonPeliculas.getJSONObject(i);
                            //Toast.makeText(context, jsonObject.toString(), Toast.LENGTH_LONG  ).show();
                            Pelicula pelicula = new Pelicula();
                            pelicula.setIdPelicula(jsonObject.getString("imdbID"));
                            pelicula.setTitulo(jsonObject.getString("Title"));
                            // Toast.makeText(context, jsonObject.getString("nombre"), Toast.LENGTH_LONG  ).show();
                            pelicula.setAño(jsonObject.getString("Year"));
                            pelicula.setTipo(jsonObject.getString("Type"));
                            pelicula.setPoster(jsonObject.getString("Poster"));
                            //Toast.makeText(context, jsonObject.getString("Poster"), Toast.LENGTH_LONG  ).show();
                            listaPelicula.add(pelicula);

                        }





                } catch (JSONException e) {
                    Log.e("ERROR", e.getMessage());
                    e.printStackTrace();
                }


            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                //  Log.e("ERROR", error.getMessage());

            }
        }

        );
        VolleyPeliculaSingleton.getInstance(context).addToRequestque(jsonObjectRequest);
        Log.d("Lista", listaPelicula.size()+"");
        return listaPelicula;
    }

    public List<Pelicula> buscarID(String id, String filtro) {
        String url = host + filtro + id + api_key;
        Log.d("DATOS", url);
        listaPelicula.clear();
        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                Log.d("DATOS", response.toString());
                try {
                    JSONArray datos = response.getJSONArray("Search");
                    for (int i = 0; i < datos.length(); i++) {
                        Log.d("DATOS", datos.getJSONObject(i).getString("Title"));
                        listaPelicula.add(new Pelicula(datos.getJSONObject(i).getString("Title"), datos.getJSONObject(i).getString("Year"), datos.getJSONObject(i).getString("Type"), datos.getJSONObject(i).getString("imdbID"), datos.getJSONObject(i).getString("Poster")));
                    }
                } catch (JSONException e) {
                    JSONObject datos = response;
                    try {
                        Log.d("DATOS", datos.getString("Title"));
                        listaPelicula.add(new Pelicula(datos.getString("imdbID"), datos.getString("Title"), datos.getString("Year"), datos.getString("Genre"), datos.getString("Poster")));
                    } catch (JSONException e1) {
                        e1.printStackTrace();
                    }

                    Log.e("JASON ERROR", e.getMessage());Log.e("JASON ERROR", e.getMessage());
                }
            }
        },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.e("ERRORRR", error.getMessage());
                    }
                });
        VolleyPeliculaSingleton.getInstance(context).addToRequestque(request);
        return listaPelicula;
    }



    public List<Pelicula> buscar(String titulo, String año, String filtro) {
        String url = host + filtro + titulo + "&" +
                "y=" + año + api_key;
        Log.d("DATOS", url);
        listaPelicula.clear();
        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                Log.d("DATOS", response.toString());
                try {
                    JSONArray datos = response.getJSONArray("Search");
                    for (int i = 0; i < datos.length(); i++) {
                        Log.d("DATOS", datos.getJSONObject(i).getString("Title"));
                        listaPelicula.add(new Pelicula(datos.getJSONObject(i).getString("Title"), datos.getJSONObject(i).getString("Year"), datos.getJSONObject(i).getString("Type"), datos.getJSONObject(i).getString("imdbID"), datos.getJSONObject(i).getString("Poster")));
                    }
                } catch (JSONException e) {
                    JSONObject datos = response;
                    try {
                        Log.d("DATOS", datos.getString("Title"));
                        listaPelicula.add(new Pelicula(datos.getString("imdbID"), datos.getString("Title"), datos.getString("Year"), datos.getString("Genre"), datos.getString("Poster")));
                    } catch (JSONException e1) {
                        e1.printStackTrace();
                    }

                    Log.e("JASON ERROR", e.getMessage());Log.e("JASON ERROR", e.getMessage());
                }
            }
        },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
                });
        VolleyPeliculaSingleton.getInstance(context).addToRequestque(request);
        return listaPelicula;
    }


   /* public List<Pelicula> obtenerPorTitulo(final String titulo) {
        //String url = host + buscar_titulo + titulo;
        listaPelicula.clear();


        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                //me devuelve un json

                try {

                    Pelicula pelicula = new Pelicula();
                    pelicula.setIdPelicula(response.getJSONObject("").getString("imdbID"));
                    pelicula.setTitulo(response.getJSONObject("").getString("Title"));
                    pelicula.setAño(response.getJSONObject("").getString("Year"));
                    pelicula.setTipo(response.getJSONObject("").getString("Type"));
                    //pelicula.setDatos(response.getJSONObject("").getString("Poster"));
                    listaPelicula.add(pelicula);
                    Toast.makeText(context, pelicula.toString(), Toast.LENGTH_LONG).show();



                } catch (JSONException e) {
                    e.printStackTrace();
                    Log.e("ERROR", e.getMessage());
                }


            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e("ERROR", error.getMessage());

            }
        }

        );
        VolleyAlumnoSingleton.getInstance(context).addToRequestque(jsonObjectRequest);
        Log.e("Lista", listaPelicula.size()+"");
        return listaPelicula;
    }*/









}
