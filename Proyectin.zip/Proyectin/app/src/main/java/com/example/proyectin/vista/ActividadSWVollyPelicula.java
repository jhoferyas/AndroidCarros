package com.example.proyectin.vista;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.proyectin.R;
import com.example.proyectin.controlador.swvolly.ServicioWebVollyPelicula;
import com.example.proyectin.modelo.Pelicula;
import com.example.proyectin.vista.adapter.PeliculaAdapter;

import java.util.ArrayList;
import java.util.List;

public class ActividadSWVollyPelicula extends AppCompatActivity implements View.OnClickListener {

    EditText cajaID, cajaTitulo, cajaAño, cajaTipo;
    Button botonBuscarTodos, botonBuscarId, botonBuscarTitulo;
    ServicioWebVollyPelicula servicioWebVollyPelicula;

    RecyclerView recyclerViewPelicula;
    PeliculaAdapter adapter;
    private List<Pelicula> pelicula;
    String filtro1 = "t=";
    String filtro2 = "s=";
    String filtro3 = "i=";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_actividad_swvolly_pelicula);
        tomarControl();
        servicioWebVollyPelicula = new ServicioWebVollyPelicula(ActividadSWVollyPelicula.this);
        cargarLista(servicioWebVollyPelicula.obtenerTodos(cajaTitulo.getText().toString(), filtro2));

    }


    public void tomarControl(){
        cajaID = findViewById(R.id.txtIdPeliculaVolly);
        cajaTitulo = findViewById(R.id.txtTituloPeliculaVolly);
        cajaAño = findViewById(R.id.txtAñoPeliculaVolly);
        cajaTipo = findViewById(R.id.txtTipoPeliculaVolly);

        botonBuscarTitulo = findViewById(R.id.btnBuscarTituloVolly);
        botonBuscarId = findViewById(R.id.btnBuscarIDPeliculaVolly);
        botonBuscarTodos = findViewById(R.id.btnBuscarTodasPeliculasVolly);


        botonBuscarTodos.setOnClickListener(this);
        botonBuscarTitulo.setOnClickListener(this);
        botonBuscarId.setOnClickListener(this);

    }

    private void cargarLista(List<Pelicula> lista) {
        pelicula = new ArrayList<Pelicula>();
        pelicula = lista;

        adapter = new PeliculaAdapter(pelicula, this);
        adapter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Pelicula a = adapter.obtenerPelicula(recyclerViewPelicula.getChildAdapterPosition(v));
                cajaID.setText(a.getIdPelicula());
                cajaTitulo.setText(a.getTitulo());
                cajaAño.setText(a.getAño());
                cajaTipo.setText(a.getTipo());
            }
        });
        recyclerViewPelicula = findViewById(R.id.recyclerPeliculaVolly);
        recyclerViewPelicula.setLayoutManager(new LinearLayoutManager(this));
        recyclerViewPelicula .setAdapter(adapter);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btnBuscarTodasPeliculasVolly:
                cargarLista(servicioWebVollyPelicula.obtenerTodos(cajaTitulo.getText().toString(), filtro2));
                //Log.e("Lista",servicioWebVollyPelicula.obtenerTodos().toString());


            case R.id.btnBuscarTituloVolly:
                cargarLista(servicioWebVollyPelicula.buscar(cajaTitulo.getText().toString(),cajaAño.getText().toString(), filtro1));

                break;

            case R.id.btnBuscarIDPeliculaVolly:
                cargarLista(servicioWebVollyPelicula.buscarID(cajaID.getText().toString(), filtro3));
                //Log.e("ID", servicioWebVollyPelicula.obtenerPorId("imdbID=" + cajaID.getText().toString())+"");

                break;
        }


    }
}
