package com.example.proyectin.vista;

import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.proyectin.R;
import com.example.proyectin.controlador.ArchivoProducto;
import com.example.proyectin.modelo.Producto;

public class ActividadEscribirMemoria extends AppCompatActivity implements View.OnClickListener {

    EditText cajaCodigo, cajaNombre, cajaPrecio, cajaExistencia;
    Button botonRegistro;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_actividad_escribir_memoria);

        cajaCodigo = findViewById(R.id.txtCodigoProducto);
        cajaNombre = findViewById(R.id.txtNombreProducto);
        cajaPrecio = findViewById(R.id.txtPrecioProducto);
        cajaExistencia = findViewById(R.id.txtExistencia);
        botonRegistro =  findViewById(R.id.btnRegistroProducto);

        botonRegistro.setOnClickListener(this);
        setupActionBar();

    }
    private void setupActionBar(){
        ActionBar actionBar = getSupportActionBar();
        if(actionBar == null){
            actionBar.setDisplayHomeAsUpEnabled(true);
            actionBar.setTitle("Escribir Archivo");

        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btnRegistroProducto:
                try{
                    ArchivoProducto archivoProducto = new ArchivoProducto(ActividadEscribirMemoria.this);
                    Producto producto = new Producto();
                    producto.setNombre(cajaNombre.getText().toString());
                    producto.setCodigo(cajaCodigo.getText().toString());
                    producto.setExistencia(Integer.parseInt(cajaExistencia.getText().toString()));
                    producto.setPrecio(Double.parseDouble(cajaPrecio.getText().toString()));

                    archivoProducto.guardarProducto(producto);
                    Toast.makeText(ActividadEscribirMemoria.this, "Producto Agregado", Toast.LENGTH_SHORT).show();
                }catch (Exception ex){
                    Log.e("Error De Lectura", ex.getMessage());
                }

                break;
        }


    }
}
