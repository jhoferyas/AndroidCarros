package com.example.proyectin.controlador.swvolly;

import android.content.Context;
import android.util.Log;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.example.proyectin.modelo.Alumno;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class ServicioWebVolley {

    String host = "http://reneguaman.000webhostapp.com";
    String insertar_url = "/insertar_alumno.php";
    String update_url = "/actualizar_alumno.php";
    String buscar_url = "/obtener_alumnos.php";
    String eliminar_url = "/borrar_alumno.php";
    Context context;
    boolean estado;
   final private List<Alumno> listaAlumnos;


    public ServicioWebVolley(Context context) {
        this.context = context;
        listaAlumnos = new ArrayList<Alumno>();
    }

    public boolean insertar(Alumno alumno) {
        String url = host + insertar_url;
        JSONObject json = new JSONObject();
        try {
            json.put("nombre", alumno.getNombre());
            json.put("direccion", alumno.getDireccion());
        } catch (JSONException e) {
            e.printStackTrace();
        }
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.POST, url, json, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                estado = true;

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                estado = false;

            }
        }

        );
        VolleyAlumnoSingleton.getInstance(context).addToRequestque(jsonObjectRequest);
        return estado;
    }

    public boolean modificar(Alumno alumno) {
        String url = host + update_url;
        JSONObject json = new JSONObject();
        try {
            json.put("idalumno", alumno.getId());
            json.put("nombre", alumno.getNombre());
            json.put("direccion", alumno.getDireccion());
        } catch (JSONException e) {
            e.printStackTrace();
        }
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.POST, url, json, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                estado = true;

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                estado = false;

            }
        }

        );
        VolleyAlumnoSingleton.getInstance(context).addToRequestque(jsonObjectRequest);
        return estado;
    }

    public boolean eliminar(Alumno alumno) {
        String url = host + eliminar_url;
        JSONObject json = new JSONObject();
        try {
            json.put("idalumno", alumno.getId());
        } catch (JSONException e) {
            e.printStackTrace();
        }
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.POST, url, json, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                estado = true;

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                estado = false;

            }
        }

        );
        VolleyAlumnoSingleton.getInstance(context).addToRequestque(jsonObjectRequest);
        return estado;
    }

    public List<Alumno> obtenerTodos() {
        String url = "http://reneguaman.000webhostapp.com/obtener_alumnos.php";

        String consulta = "";
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                //me devuelve un json
                try {
                    String estado = response.getString("estado");
                    if (estado.equals("1")) {

                        JSONArray jsonAlumnos = response.getJSONArray("alumnos");
                        Toast.makeText(context, "numero lista: " + jsonAlumnos.length(), Toast.LENGTH_LONG).show();
                        for (int i = 0; i < jsonAlumnos.length(); i++) {
                            JSONObject jsonObject = jsonAlumnos.getJSONObject(i);
                            //Toast.makeText(context, jsonObject.toString(), Toast.LENGTH_LONG  ).show();
                            Alumno alumno = new Alumno();
                            alumno.setId(jsonObject.getString("idalumno"));
                            alumno.setNombre(jsonObject.getString("nombre"));
                            // Toast.makeText(context, jsonObject.getString("nombre"), Toast.LENGTH_LONG  ).show();
                            alumno.setDireccion(jsonObject.getString("direccion"));
                            listaAlumnos.add(alumno);

                        }


                    }

                } catch (JSONException e) {
                    Log.e("ERROR", e.getMessage());
                    e.printStackTrace();
                }


            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
              //  Log.e("ERROR", error.getMessage());

            }
        }

        );
        VolleyAlumnoSingleton.getInstance(context).addToRequestque(jsonObjectRequest);
        Log.d("Lista", listaAlumnos.size()+"");
        return listaAlumnos;
    }


    public List<Alumno> obtenerPorId(final String codigo) {
        String url = "http://reneguaman.000webhostapp.com/obtener_alumno_por_id.php" + codigo;
        listaAlumnos.clear();


        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                //me devuelve un json

                try {

                    String estado = response.getString("estado");

                    if(estado.equals("1")){
                        Toast.makeText(context,  "estado: " + estado, Toast.LENGTH_SHORT).show();
                        Alumno alumno = new Alumno();
                        alumno.setId(response.getJSONObject("alumno").getString("idAlumno"));
                        alumno.setNombre(response.getJSONObject("alumno").getString("nombre"));
                        alumno.setDireccion(response.getJSONObject("alumno").getString("direccion"));
                        listaAlumnos.add(alumno);
                        Toast.makeText(context, alumno.toString(), Toast.LENGTH_LONG).show();


                    }else{
                        Toast.makeText(context, "No existe ese estudiante", Toast.LENGTH_LONG).show();


                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                    Log.e("ERROR", e.getMessage());
                }


            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e("ERROR", error.getMessage());

            }
        }

        );
        VolleyAlumnoSingleton.getInstance(context).addToRequestque(jsonObjectRequest);
        Log.e("Lista", listaAlumnos.size()+"");
        return listaAlumnos;
    }






}
