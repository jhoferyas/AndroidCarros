package com.example.proyectin.vista;


import android.app.Dialog;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.proyectin.R;
import com.example.proyectin.vista.adapter.ProductoAdapter;
import com.example.proyectin.controlador.HelperProducto;
import com.example.proyectin.modelo.Producto;

import java.util.ArrayList;
import java.util.List;

public class ActividadBDProducto extends AppCompatActivity implements View.OnClickListener{
    EditText cajaNombre, cajaDescripcion, cajaCodigo, cajaExistencia, cajaPrecio;
    Button botonGuardar, botonModificar, botonEliminar, botonBuscarTodos, botonBuscarCodigo;


    RecyclerView recyclerViewProducto;
    private List<Producto> listaProducto;
    HelperProducto helperProducto;
    ProductoAdapter adapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_actividad_bdproducto);
        tomarControl();
        setupActionBar();

        helperProducto = new HelperProducto(ActividadBDProducto.this);

        listaProducto = new ArrayList<Producto>();
        listaProducto = helperProducto.getAllProductos();
        adapter = new ProductoAdapter(helperProducto.getAllProductos());
        recyclerViewProducto.setLayoutManager(new LinearLayoutManager(this));

//esto lo hice yo
   cargarLista(helperProducto.getAllProductos());

    }

    public void cargarLista(List<Producto> lista){
        listaProducto = new ArrayList<Producto>();
        listaProducto = lista;
        recyclerViewProducto.setLayoutManager(new LinearLayoutManager(this));
        adapter = new ProductoAdapter(listaProducto);
        adapter.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                Dialog dialogInformation = new Dialog(ActividadBDProducto.this);
                dialogInformation.requestWindowFeature(Window.FEATURE_LEFT_ICON);
                dialogInformation.setContentView(R.layout.dlg_informacion);
                dialogInformation.setTitle("Informacion");



                TextView codigo = dialogInformation.findViewById(R.id.lblCodigoDialogo);
                TextView nombre = dialogInformation.findViewById(R.id.lblNombreDialogo);
                TextView descripcion = dialogInformation.findViewById(R.id.lblDescripcionDialogo);
                TextView precio = dialogInformation.findViewById(R.id.lblPrecioDialogo);
                TextView existencia = dialogInformation.findViewById(R.id.lblExistenciaDialogo);
                dialogInformation.show();

                codigo.setText(helperProducto.getAllProductos().get(recyclerViewProducto.getChildAdapterPosition(v)).getCodigo());
                nombre.setText(helperProducto.getAllProductos().get(recyclerViewProducto.getChildAdapterPosition(v)).getNombre());
                descripcion.setText(helperProducto.getAllProductos().get(recyclerViewProducto.getChildAdapterPosition(v)).getDescripcion());
                precio.setText(helperProducto.getAllProductos().get(recyclerViewProducto.getChildAdapterPosition(v)).getPrecio()+"");
                existencia.setText(helperProducto.getAllProductos().get(recyclerViewProducto.getChildAdapterPosition(v)).getExistencia()+"");


                Toast.makeText(getApplicationContext(), "Selecciono: "+
                                helperProducto.getAllProductos().get(recyclerViewProducto.getChildAdapterPosition(v)).getNombre(),
                        Toast.LENGTH_SHORT).show();
            }
        });
        recyclerViewProducto.setAdapter(adapter);


    }
    public void tomarControl(){
        cajaNombre = findViewById(R.id.txtNombreProductoBD);
        cajaDescripcion = findViewById(R.id.txtDescripcionBD);
        cajaCodigo = findViewById(R.id.txtCodigoProductoBD);
        cajaExistencia = findViewById(R.id.txtExistenciaBD);
        cajaPrecio = findViewById(R.id.txtPrecioProductoBD);


        //datos = findViewById(R.id.lblLeerBD);


        botonGuardar = findViewById(R.id.btnInsertar);
        botonModificar = findViewById(R.id.btnActualizar);
        botonEliminar = findViewById(R.id.btnBorrar);
        botonBuscarCodigo = findViewById(R.id.btnBuscarCodigo);
        botonBuscarTodos = findViewById(R.id.btnBuscar);

        botonGuardar.setOnClickListener(this);
        botonModificar.setOnClickListener(this);
        botonEliminar.setOnClickListener(this);
        botonBuscarCodigo.setOnClickListener(this);
        botonBuscarTodos.setOnClickListener(this);
        recyclerViewProducto = findViewById(R.id.recyclerProducto);

    }
    private void setupActionBar(){
        ActionBar actionBar = getSupportActionBar();
        if(actionBar == null){
            actionBar.setDisplayHomeAsUpEnabled(true);
            //actionBar.setTitle("Escribir Archivo");

        }
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btnInsertar:
                Producto producto = new Producto();
                producto.setNombre(cajaNombre.getText().toString());
                producto.setDescripcion(cajaDescripcion.getText().toString());
                producto.setCodigo(cajaCodigo.getText().toString());
                producto.setExistencia(Integer.parseInt(cajaExistencia.getText().toString()));
                producto.setPrecio(Double.parseDouble(cajaPrecio.getText().toString()));
                helperProducto.insertar(producto);
                cargarLista(helperProducto.getAllProductos());
                break;
            case R.id.btnBuscar:
                cargarLista(helperProducto.getAllProductos());
                break;
            case R.id.btnActualizar:
                Producto producto2 = new Producto();
                producto2.setNombre(cajaNombre.getText().toString());
                producto2.setDescripcion(cajaDescripcion.getText().toString());
                producto2.setCodigo(cajaCodigo.getText().toString());
                producto2.setExistencia(Integer.parseInt(cajaExistencia.getText().toString()));
                producto2.setPrecio(Double.parseDouble(cajaPrecio.getText().toString()));
                helperProducto.update(producto2);
                cargarLista(helperProducto.getAllProductos());
                break;
            case R.id.btnBuscarCodigo:
                cargarLista(helperProducto.getByCode(cajaCodigo.getText().toString()));
                break;
            case R.id.btnBorrar:
                helperProducto.eliminarPorCodigo(cajaCodigo.getText().toString());
                cargarLista(helperProducto.getAllProductos());
                break;


        }


    }
}
