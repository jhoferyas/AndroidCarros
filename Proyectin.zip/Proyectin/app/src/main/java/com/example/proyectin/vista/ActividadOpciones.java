package com.example.proyectin.vista;

import android.app.Dialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.proyectin.R;

public class ActividadOpciones extends AppCompatActivity  implements View.OnClickListener{

    Button botonLogin, botonSensores, botonArchivos, botonSql;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_actividad_opciones);

        botonLogin = (Button) findViewById(R.id.btnLogin);
        botonSensores = (Button) findViewById(R.id.btnSensores);
        botonArchivos = (Button) findViewById(R.id.btnArchivos);
        botonSql = (Button) findViewById(R.id.btnSql);

        botonLogin.setOnClickListener(this);
    }
    @Override
    public void onClick(View v) {
        Intent intent = null;
        switch (v.getId()){
            case R.id.btnLogin:
                intent= new Intent(ActividadOpciones.this, MainActivity.class);
                break;

        }
        startActivity(intent);



    }
//metodo para agregar un menu en la activity
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.main, menu);
        return true;

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        Intent intent;
        switch (item.getItemId()){
            case R.id.opcionDialogo:
                Dialog dialogoSumar = new Dialog(ActividadOpciones.this);
                dialogoSumar.setContentView(R.layout.dlg_suma);
                dialogoSumar.show();
                final EditText n1 = dialogoSumar.findViewById(R.id.txtNumero1);
                final EditText n2 = dialogoSumar.findViewById(R.id.txtNumero2);
                Button botonSuma = dialogoSumar.findViewById(R.id.btnSumar);
                botonSuma.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        int resultado = Integer.parseInt(n1.getText().toString()) + Integer.parseInt(n2.getText().toString());
                        Toast.makeText(ActividadOpciones.this, "Suma = " + resultado, Toast.LENGTH_SHORT).show();
                    }
                });

               // intent = new Intent(ActividadOpciones.this, MainActivity.class);
                //startActivity(intent);
                dialogoSumar.show();
                break;
            case R.id.opcionEscribirMI:
                intent = new Intent(ActividadOpciones.this, ActividadEscribirMemoria.class);
                startActivity(intent);
                break;
            case R.id.opcionLeerMI:
                intent = new Intent(ActividadOpciones.this, ActividadLeerMI.class);
                startActivity(intent);
                break;
            case R.id.opcionRaw:
                intent = new Intent(ActividadOpciones.this, ActividadArchivoRaw.class);
                startActivity(intent);
                break;
            case R.id.opcionSD:
                intent = new Intent(ActividadOpciones.this, ActividadArchivoSD.class);
                startActivity(intent);
                break;

            case R.id.opcionHelper:
                intent = new Intent(ActividadOpciones.this, ActividadBDProducto.class);
                startActivity(intent);
                break;

            case R.id.opcionORM:
                intent = new Intent(ActividadOpciones.this, ActividadProductoORM.class);
                startActivity(intent);
                break;


        }
        return true;
    }
}
